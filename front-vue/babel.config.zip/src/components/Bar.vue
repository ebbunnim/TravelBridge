<template>
  <div>
    <div>
      <div class="row">
        <div
          v-for="(menu, index) in menuList"
          :key="index"
          class="col-3 bg-white q-pa-none"
          @mouseover="menuOver = true"
          @mouseout="menuOver = false"
        >
          <div class="fit flex flex-center text-center">
            <p style="color: black;">
              {{ menu.menuName }}
            </p>
          </div>
        </div>
        <!-- <q-menu v-model="menu"> -->
        <q-menu v-model="menu" class="q-ma-none q-pa-none" align="left">
          <q-list
            class="row temp q-ma-lg"
            @mouseover.native="listOver = true"
            @mouseout.native="listOver = false"
          >
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>홈홈홈홈</q-item>
              <q-item clickable>홈홈홈홈</q-item>
              <q-item clickable>홈홈홈홈</q-item>
            </div>

            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>홈홈홈홈</q-item>
              <q-item clickable>홈홈홈홈</q-item>
              <q-item clickable>홈홈홈홈</q-item>
            </div>
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>홈홈홈홈</q-item>
              <q-item clickable>홈홈홈홈</q-item>
              <q-item clickable>홈홈홈홈</q-item>
            </div>
          </q-list>
        </q-menu>
        <q-menu v-model="menu" align="left">
          <q-list
            class="row temp q-ma-lg"
            @mouseover.native="listOver = true"
            @mouseout.native="listOver = false"
          >
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>메인1</q-item>
              <q-item clickable>메인1</q-item>
              <q-item clickable>메인1</q-item>
            </div>

            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>메인1</q-item>
              <q-item clickable>메인1</q-item>
              <q-item clickable>메인1</q-item>
            </div>
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>메인1</q-item>
              <q-item clickable>메인1</q-item>
              <q-item clickable>메인1</q-item>
            </div>
          </q-list>
        </q-menu>
        <q-menu v-model="menu" align="left">
          <q-list
            class="row temp q-ma-lg"
            @mouseover.native="listOver = true"
            @mouseout.native="listOver = false"
          >
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>메인2</q-item>
              <q-item clickable>메인2</q-item>
              <q-item clickable>메인2</q-item>
            </div>

            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>메인2</q-item>
              <q-item clickable>메인2</q-item>
              <q-item clickable>메인2</q-item>
            </div>
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>메인2</q-item>
              <q-item clickable>메인2</q-item>
              <q-item clickable>메인2</q-item>
            </div>
          </q-list>
        </q-menu>
        <q-menu align="left">
          <q-list
            class="row temp q-ma-lg"
            @mouseover.native="listOver = true"
            @mouseout.native="listOver = false"
          >
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>서브서브</q-item>
              <q-item clickable>서브서브</q-item>
              <q-item clickable>서브서브</q-item>
            </div>

            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>서브서브</q-item>
              <q-item clickable>서브서브</q-item>
              <q-item clickable>서브서브</q-item>
            </div>
            <div class="col-4" style="text-align:center;" v-close-popup>
              <q-item clickable>서브서브</q-item>
              <q-item clickable>서브서브</q-item>
              <q-item clickable>서브서브</q-item>
            </div>
          </q-list>
        </q-menu>
      </div>
    </div>
  </div>
</template>

<script>
import { debounce } from "quasar";

export default {
  data() {
    return {
      id: 0,
      menu: false,
      menuOver: false,
      listOver: false,
      menuList: [
        {
          menuId: 1,
          menuName: "홈",
          menuItems: { first: "홈1", second: "홈2", third: "홈3" }
        },
        {
          menuId: 2,
          menuName: "트래블 카드",
          menuItems: { first: "카드1", second: "카드2", third: "카드3" }
        },
        {
          menuId: 3,
          menuName: "트래블 픽",
          menuItems: { first: "픽1", second: "픽2", third: "픽3" }
        },
        {
          menuId: 4,
          menuName: "서브기능",
          menuItems: { first: "서브1", second: "서브2", third: "서브3" }
        }
      ]
    };
  },
  methods: {
    debounceFunc: debounce(function() {
      this.checkMenu();
      this.onItemClick();
    }, 300),
    onItemClick() {
      console.log("호버함");
    },
    checkMenu() {
      if (this.menuOver || this.listOver) {
        this.menu = true;
      } else {
        this.menu = false;
      }
    },
    setNum(id) {
      this.id = id;
    }
  },
  watch: {
    menuOver(val) {
      this.debounceFunc();
    },
    listOver(val) {
      this.debounceFunc();
    }
  }
};
</script>

<style>
.temp {
  min-width: 1200px;
  min-height: 250px;
}
</style>
