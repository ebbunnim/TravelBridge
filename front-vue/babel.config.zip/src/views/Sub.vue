<template>
  <div>
      <h1>Sub페이지</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>